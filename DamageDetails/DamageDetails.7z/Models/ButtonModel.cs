﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamageMaker.Models
{
    public class ButtonModel
    {
        public string Content { get; set; }
        public double X { get; set; }
        public double Y { get; set; }

    }
}
