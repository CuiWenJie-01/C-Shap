﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamageMaker.Models
{
    public class ScreenshotInfo
    {
        public int ScreenshotOffset { get; set; }

        public int ScreenshotWidthPx { get; set; }
        public MoveDirection ScreenshotDirection { get; set; }

        public RailInfo RailWayInfo { get; set; }


    }
    public class RailInfo
    {

        public string RailwayName { get; set; }
        //铁轨起始里程
        public string? RailwayStartMileage { get; set; }
        //铁轨终止里程
        public string? RailwayEndMileage { get; set; }
        //操作人
        public string? OperatorName { get; set; }
        //检测时间       
        public string? DetectionTime { get; set; }


    }

}
