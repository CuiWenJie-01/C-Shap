﻿namespace DamageMaker.Models
{
    public class ProgressData
    {
        public string progress { get; set; }
    }
}
