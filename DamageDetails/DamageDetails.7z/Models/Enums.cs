﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamageMaker.Models
{

    public enum DamageCategory
    {
        接头,
        零度迟到波,
        焊缝,
        七十度螺孔回波,
        轨形变换,
        轨头核伤,
        焊缝核伤,
        螺孔裂纹,
        零度异常,
        轨腰裂纹,
        轨底裂纹_规则,
        加固焊缝,
        断面,
        轨面剥离,
        焊缝标记,
        无伤标记,
        焊缝且无伤标记,
        轻伤标记,
        轻伤发展,
        重伤标志,
        作业违规,
        焊缝且无焊缝标记,
        假像波,
        鱼鳞伤_规则,
        岔心,
        核伤2_模型,
        核伤3_规则,
        核伤1_规则,
        正常螺孔,
        核伤2_模型_焊缝附近,
        核伤2_规则,
        核伤2_规则_焊缝附近,
        水平裂纹_规则,
        斜裂纹_规则,
        月牙伤2_规则,
        未知异常,
    }
    public enum MoveDirection
    {
        Left,
        Right
    }


}
