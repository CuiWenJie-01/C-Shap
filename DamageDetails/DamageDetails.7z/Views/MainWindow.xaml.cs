﻿using DamageMaker.Common;
using DamageMaker.Views;
using DamageMarker.ViewModels;
using HandyControl.Controls;
using HandyControl.Interactivity;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace DamageMarker.Views
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow
    {

        public static MainWindowViewModel MainVm;
        public MainWindow()
        {
            InitializeComponent();
            NonClientAreaContent = new NonClient();
            MainVm = new MainWindowViewModel();
            DataContext = MainVm;
            MainWindowViewModel.ScreenShotPopuped += OnScreenShotPopuped;
            PlaybackWindow.ScreenshotFinished += OnScreenshotFinished;
            Scal.ScaleX = 1 / DamageMaker.Common.Monitor.ScaleX;
            Scal.ScaleY = 1 / DamageMaker.Common.Monitor.ScaleY;

        }
        private void OnScreenShotPopuped(object sender, EventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        private void OnScreenshotFinished(object sender, EventArgs e)
        {
            WindowState = WindowState.Maximized;
        }
        protected override void OnClosing(CancelEventArgs e)
        {

            base.OnClosing(e);
            if (MainVm.Cap != null)
            {
                MainVm.Cap.Close();
            }
        }



        private void bthClick(object sender, RoutedEventArgs e)
        {
            Geometry? EyeCloseGeometry = System.Windows.Application.Current.FindResource("EyeCloseGeometry") as Geometry;
            Geometry? EyeOpenGeometry = System.Windows.Application.Current.FindResource("EyeOpenGeometry") as Geometry;
            var bth = sender as ToggleButton;

            if (bth != null)
            {
                if (bth.IsChecked ?? false)
                {
                    HandyControl.Controls.IconElement.SetGeometry(bth, EyeCloseGeometry);
                }
                else
                {
                    HandyControl.Controls.IconElement.SetGeometry(bth, EyeOpenGeometry);
                }
            }
        }

        private void ThumbnailList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ThumbnailList.ScrollIntoView((sender as ListBox).SelectedItem);
        }

        private void TextBlock_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var t = (sender as TextBlock)?.Text ?? " ";
            if (t.Contains("核伤1"))
            {
                RuleInfo.Text = "核伤1：在轨头区域找冒尖的，纵坐标最长（3个点以上）";

            }
            else if (t.Contains("核伤2"))
            {
                RuleInfo.Text = "核伤2：在一次波区域（2个点以上）";

            }
            else if (t.Contains("核伤3"))
            {

                RuleInfo.Text = "核伤3:在轨头区域找零星单个的（3个点以上）";

            }
            else if (t.Contains("鱼鳞伤"))
            {
                RuleInfo.Text = "鱼鳞伤：在轨头区域找较长的鱼鳞伤（6个点以上）";
            }
            else if (t.Contains("轨底裂纹")) {

                RuleInfo.Text = "轨底裂纹：找轨底正八字";

            }


        }
    }
}
